Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root to: 'books#top'
  get '/index' => 'books#index'
  get '/show' => 'books#show'
  get '/edit' => 'books#edit'
  post '/index' => 'books#create'
  get '/index/:id' => 'books#show', as: 'book' #名前付きルート
  get '/index/:id/edit' => 'books#edit', as: 'edit_book'
  patch '/index/:id/edit' => 'books#update', as: 'update_book'
  delete '/index/:id' => 'books#destroy', as: 'destroy_book'
  resources :books
end